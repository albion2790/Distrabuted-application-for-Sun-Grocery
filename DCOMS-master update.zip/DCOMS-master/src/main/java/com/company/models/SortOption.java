package com.company.models;

public enum SortOption {
    BY_DATE,
    BY_NAME,
    BY_CATEGORY,
    BY_STOCK,
    BY_PRICE,
    BY_DESC,
}
